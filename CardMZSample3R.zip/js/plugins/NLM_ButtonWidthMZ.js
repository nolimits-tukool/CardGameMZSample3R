﻿/*==========================================================================
 NLM_ButtonWidthMZ.js
----------------------------------------------------------------------------
 (C)2024-2026 NoLimits
 This software is released under the MIT License.
 http://opensource.org/licenses/mit-license.php
----------------------------------------------------------------------------
 Version
 1.0.0  2024/03/02 試作版初稿
 1.0.1  2024/03/03 色調変更追加
 1.1.0  2026/02/17 一部改良
============================================================================*/

/*:
 * @target MZ
 * @plugindesc MZ用ボタン幅拡大プラグイン
 * @author ノリミツ (NoLimits)
 * @url https://github.com/nolimits-tukool
 * 
 * @param cancel
 * @desc 「キャンセル」ボタンの幅の倍数（デフォルト：2）
 * @type number
 * @decimals 1
 * @default 2
 * 
 * @param pageup
 * @desc 「ページアップ」ボタンの幅の倍数（デフォルト：3）
 * @type number
 * @decimals 1
 * @default 3
 * 
 * @param pagedown
 * @desc 「ページダウン」ボタンの幅の倍数（デフォルト：3）
 * @type number
 * @decimals 1
 * @default 3
 * 
 * @param menu
 * @desc 「メニュー」ボタンの幅の倍数（デフォルト：2）
 * @type number
 * @decimals 1
 * @default 2
 * 
 * @param shop
 * @desc ショップ時のボタン設定
 * 
 * @param down1
 * @parent shop
 * @desc 「ダウン1」ボタンの幅の倍数（デフォルト：2）　　　　　　　（HDレイアウトでは 2.5 など）
 * @type number
 * @decimals 1
 * @default 2
 * 
 * @param up1
 * @parent shop
 * @desc 「アップ1」ボタンの幅の倍数（デフォルト：2）　　　　　　　（HDレイアウトでは 2.5 など）
 * @type number
 * @decimals 1
 * @default 2
 * 
 * @param down2
 * @parent shop
 * @desc 「ダウン2」ボタンの幅の倍数（デフォルト：0）　　　　　　　（HDレイアウトでは 1.5 など）
 * @type number
 * @decimals 1
 * @default 0
 * 
 * @param up2
 * @parent shop
 * @desc 「アップ2」ボタンの幅の倍数（デフォルト：0）　　　　　　　（HDレイアウトでは 1.5 など）
 * @type number
 * @decimals 1
 * @default 0
 * 
 * @param ok
 * @parent shop
 * @desc 「決定」ボタンの幅の倍数（デフォルト：1）　　　　　　　　（HDレイアウトでは 2 など）
 * @type number
 * @decimals 1
 * @default 1
 * 
 * @param color
 * @desc ボタン画像の色調(RGB)を変更できます　　　　　　　　　　　　（ツクールデフォは [ 0 , 0 , 0 ]）
 * 
 * @param red
 * @parent color
 * @desc ボタン色調変更（赤）（-255～255)（デフォルト：200）
 * @type number
 * @max 255
 * @min -255
 * @default 200
 * 
 * @param green
 * @parent color
 * @desc ボタン色調変更（緑）（-255～255)（デフォルト：70）
 * @type number
 * @max 255
 * @min -255
 * @default 70
 * 
 * @param blue
 * @parent color
 * @desc ボタン色調変更（青）（-255～255)（デフォルト：255）
 * @type number
 * @max 255
 * @min -255
 * @default 255
 * 
 * 
 * @help
 * 
 * 【RPGツクールMZ専用プラグイン】（v1.1.0）
 * ボタン幅の拡大倍率を変えます
 * 　ボタンがやや小さく押しにくいと感じたので、つくりました
 * 
 * ボタン画像を差し替える必要なく、手軽に拡大ができる点と、
 * 　ボタンの色調も変更できる点が特長です
 * 
 * 右のパラメータで、各ボタンごとの倍率を設定できます
 * 　（ボタン倍数が「0」だと、表示されなくなります）
 * 
 * 画像を拡大表示しているため、輪郭がややボケて見えるのは仕様です
 * 今のところ、ボタンの高さは変えられません
 * 
 * プラグインコマンドはありません
 * 利用規約はMITライセンスの通りです
 */

(() => {
    "use strict";

    const pluginName = "NLM_ButtonWidthMZ";
    const NLMBparam  = PluginManager.parameters(pluginName);

    const _Sprite_Button_initialize = Sprite_Button.prototype.initialize;
    Sprite_Button.prototype.initialize = function(buttonType) {
        _Sprite_Button_initialize.apply(this, arguments);
        this._NLMBfirst = false;
        this._NLMBred   = Number(NLMBparam.red)   || 0;
        this._NLMBgreen = Number(NLMBparam.green) || 0;
        this._NLMBblue  = Number(NLMBparam.blue)  || 0;
    };

    Sprite_Button.prototype.imageWidth = function() {
        return 528;
    };

    Sprite_Button.prototype.imageHeight = function() {
        return 96;
    };

    Sprite_Button.prototype.NLMBmag = function() {
        switch (this._buttonType) {
            case "cancel":
                return Number(NLMBparam.cancel)   || 0;
            case "pageup":
                return Number(NLMBparam.pageup)   || 0;
            case "pagedown":
                return Number(NLMBparam.pagedown) || 0;
            case "menu":
                return Number(NLMBparam.menu)     || 0;
            case "down":
                return Number(NLMBparam.down1)    || 0;
            case "up":
                return Number(NLMBparam.up1)      || 0;
            case "down2":
                return Number(NLMBparam.down2)    || 0;
            case "up2":
                return Number(NLMBparam.up2)      || 0;
            case "ok":
                return Number(NLMBparam.ok)       || 0;
        }
    };

    const _Sprite_Button_blockWidth = Sprite_Button.prototype.blockWidth;
    Sprite_Button.prototype.blockWidth = function() {
        const blockW = _Sprite_Button_blockWidth.call(this);
        return blockW * this.NLMBmag();
    };

    Sprite_Button.prototype.checkBitmap = function() { // 削除
    };

    const _Sprite_Button_updateFrame = Sprite_Button.prototype.updateFrame;
    Sprite_Button.prototype.updateFrame = function() {
        const pressed = this.isPressed();
        if (this._NLMBpressed !== pressed || !this._NLMBfirst) {
            this._NLMBpressed = pressed;
            const mag = this.NLMBmag();
            this.bitmap.resize(this.imageWidth() * mag, mag ? this.imageHeight() : 0);
            this.setColorTone([this._NLMBred, this._NLMBgreen, this._NLMBblue, 0]);
            _Sprite_Button_updateFrame.apply(this, arguments);
            if (!this._NLMBfirst) {
                this._NLMBfirst = true;
                this._refresh(); // タイトルでのオプション対策
            }
        }
    };
})();
