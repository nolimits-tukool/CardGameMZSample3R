﻿/*==========================================================================
 NLM_UsefulPluginMZ.js
----------------------------------------------------------------------------
 (C)2026 NoLimits
 This software is released under the MIT License.
 http://opensource.org/licenses/mit-license.php
----------------------------------------------------------------------------
 Version
 1.0.0 2026/05/09 初稿
============================================================================*/

/*:
 * @target MZ
 * @plugindesc MZ用お役立ちプラグイン (v1.0.0)
 * @author ノリミツ (NoLimits)
 * @url https://github.com/nolimits-tukool
 *
 * @command fadeIn
 * @text 時間指定フェードイン
 * @desc 遷移までのフレーム（1/60秒）を指定できるフェードイン　　　　　（ウエイトを待たないため、適宜「ウエイト」を付け足して下さい）
 * 
 * @arg frame
 * @text フレーム（定値）
 * @desc フレームを定値で入力（デフォルト：24）
 * @type number
 * @min 1
 * @default 24
 * 
 * @arg fVarId
 * @text フレーム（変数）
 * @desc フレームを変数で入力（「なし」以外にすると上記定値は無効）
 * @type variable
 * @default 0
 * 
 * @command fadeOut
 * @text 時間指定フェードアウト
 * @desc 遷移までのフレーム（1/60秒）を指定できるフェードアウト　　　　（ウエイトを待たないため、適宜「ウエイト」を付け足して下さい）
 * 
 * @arg frame
 * @text フレーム（定値）
 * @desc フレームを定値で入力（デフォルト：24）
 * @type number
 * @min 1
 * @default 24
 * 
 * @arg fVarId
 * @text フレーム（変数）
 * @desc フレームを変数で入力（「なし」以外にすると上記定値は無効）
 * @type variable
 * @default 0
 * 
 * @command battleLogDisp
 * @text 戦闘ログ文章表示
 * @desc 戦闘ログに任意の文章を出力表示（戦闘中以外では何も起きません)
 * 
 * @arg phrase
 * @text 表示文章
 * @desc 表示する文章（制御文字が使用できます）
 * @type string
 * 
 * @arg wait
 * @text ウエイト
 * @desc 文章表示後にウエイトを入れるか　　　　　　　　　　　　　　（上記文章が空欄の場合 ウエイトだけを入れることもできます)
 * @type boolean
 * @default true
 * 
 * @arg clear
 * @text ログ消去
 * @desc 最後に戦闘ログを消去するか　　　　　　　　　　　　　　　　（OFF時は改行せずに次行をもう一度プラグインコマンド実行可)
 * @type boolean
 * @default true
 * 
 * @command clearPic
 * @text ピクチャ全消去
 * @desc ピクチャを全消去します
 * 
 * @command clearHiddenA
 * @text 隠しアイテムA全削除
 * @desc 所持している隠しアイテムAの個数を全てゼロにします
 * 
 * @command clearHiddenB
 * @text 隠しアイテムB全削除
 * @desc 所持している隠しアイテムBの個数を全てゼロにします
 * 
 * @command clearSelf
 * @text セルフスイッチ全初期化
 * @desc 全マップのセルフスイッチを全初期化します
 * 
 * @command volumeBgm
 * @text BGM音量途中変更
 * @desc 演奏中のBGM音量(％)を途中変更します
 * 
 * @arg volume
 * @text 音量％（定値）
 * @desc 変更音量％を定値で入力（0-100）
 * @type number
 * @default 90
 * 
 * @arg varId
 * @text 音量％（変数）
 * @desc 変更音量％を変数で入力(「なし」以外にすると上記定値は無効)
 * @type variable
 * @default 0
 * 
 * @command volumeBgs
 * @text BGS音量途中変更
 * @desc 演奏中のBGS音量(％)を途中変更します
 * 
 * @arg volume
 * @text 音量％（定値）
 * @desc 変更音量％を定値で入力（0-100）
 * @type number
 * @default 0
 * 
 * @arg varId
 * @text 音量％（変数）
 * @desc 変更音量％を変数で入力(「なし」以外にすると上記定値は無効)
 * @type variable
 * @default 0
 * 
 * @command changeRegionId
 * @text マップリージョン一時変更
 * @desc 現在のマップ指定地点のリージョンIDを一時的に変更します　　　　（「場所移動」「ロード」コマンドを実行すると初期値に戻る）
 * 
 * @arg map
 * @text マップ指定地点
 * @desc リージョンIDを変更したい現在のマップ地点を指定します　　　　　（注意：プレイヤーが現存するマップ上でのみ有効）
 * @type location
 * 
 * @arg region
 * @text リージョンID（定値）
 * @desc 変更するリージョンIDを定値で入力（0-255）
 * @type number
 * @max 255
 * @default 0
 *
 * @arg varId
 * @text リージョンID（変数）
 * @desc 変更するリージョンIDを変数で入力（「なし」以外にすると上記定値は無効）
 * @type variable
 * @default 0
 * 
 * @command callOption
 * @text オプション画面の呼び出し
 * @desc オプション画面を呼び出します
 * 
 * @command callLoad
 * @text ロード画面の呼び出し
 * @desc ロード画面を呼び出します
 * 
 * @command callItem
 * @text アイテム画面の呼び出し
 * @desc アイテム画面を呼び出します
 * 
 * @arg category
 * @text カテゴリー呼び出し
 * @desc カテゴリー選択状態で呼び出し（デフォルト：未選択）
 * @type select
 * @option 先頭カテゴリー
 * @value xTop
 * @option アイテム
 * @value item
 * @option 武器
 * @value weapon
 * @option 防具
 * @value armor
 * @option 大事なもの
 * @value keyItem
 * @option 未選択
 * @value no
 * @default no
 * 
 * @command callSkill
 * @text スキル画面の呼び出し
 * @desc スキル画面を呼び出します（メンバーに含まれていることが条件）
 *
 * @arg actor
 * @text 指定アクター呼び出し
 * @desc 指定したアクターを選択状態で呼び出し（デフォルト：なし）　（「なし」だと先頭アクターを選択）
 * @type actor
 * @default 0
 * 
 * @arg varId
 * @text 変数でアクター呼び出し
 * @desc 変数値をIDとするアクターを呼び出し（デフォルト：なし）　　（「なし」以外にすると上記の指定呼び出しは無効）
 * @type variable
 * @default 0
 * 
 * @command callEquip
 * @text 装備画面の呼び出し
 * @desc 装備画面を呼び出します（メンバーに含まれていることが条件）
 * 
 * @arg actor
 * @text 指定アクター呼び出し
 * @desc 指定したアクターを選択状態で呼び出し（デフォルト：なし）　（「なし」だと先頭アクターを選択）
 * @type actor
 * @default 0
 * 
 * @arg varId
 * @text 変数でアクター呼び出し
 * @desc 変数値をIDとするアクターを呼び出し（デフォルト：なし）　　（「なし」以外にすると上記の指定呼び出しは無効）
 * @type variable
 * @default 0
 * 
 * @command callStatus
 * @text ステータス画面の呼び出し
 * @desc ステータス画面を呼び出します（ページボタンOFF時のみ メンバーに含まれなくても表示可）
 * 
 * @arg actor
 * @text 指定アクター呼び出し
 * @desc 指定したアクターを選択状態で呼び出し（デフォルト：なし）　（「なし」だと先頭アクターを選択）
 * @type actor
 * @default 0
 * 
 * @arg varId
 * @text 変数でアクター呼び出し
 * @desc 変数値をIDとするアクターを呼び出し（デフォルト：なし）　　（「なし」以外にすると上記の指定呼び出しは無効）
 * @type variable
 * @default 0
 * 
 * @arg pageButton
 * @text ページボタン
 * @desc ページボタンの有無（デフォルト：ON）　　　　　　　　　　　（メンバーに存在しないアクターを選択時はOFFにすること）
 * @type boolean
 * @default true
 * 
 * 
 * @param titleSkip
 * @text タイトルスキップ
 * @desc デプロイメント後もタイトルスキップして初期位置MAPから開始（デフォルト：OFF)（スプラッシュ画面もスキップされる）
 * @type boolean
 * @default false
 * 
 * @param fadeOutStart
 * @text フェードアウト開始
 * @desc フェードアウトした状態からゲーム開始（デフォルト：OFF）
 * @type boolean
 * @default false
 * 
 * @param addLoad
 * @text ロードコマンド追加
 * @desc メニューで「ロード」コマンド追加（デフォルト：OFF)
 * @type boolean
 * @default false
 * 
 * @param loadName
 * @parent addLoad
 * @text ロード名称
 * @desc ロードコマンドの名称（デフォルト：ロード）
 * @type string
 * @default ロード
 * 
 * @param deleteGameEnd
 * @text ゲーム終了削除
 * @desc メニューで「ゲーム終了」コマンド削除（デフォルト：OFF）
 * @type boolean
 * @default false
 * 
 * @param omitMenuActor
 * @text 一人旅最初選択省略
 * @desc 一人旅時でメニュー最初のアクター選択を省略（デフォルト：ON) （アイテム・スキルメニューでの対象選択は省略しない）
 * @type boolean
 * @default true
 * 
 * @param dropIcon
 * @text ドロップアイコン表示
 * @desc 戦闘後の敵からのドロップアイテムがあった時に名前だけでなくアイコンも表示する（デフォルト：ON）
 * @type boolean
 * @default true
 * 
 * @param logSpeedVarId
 * @text 戦闘ログ速度変数ID
 * @desc 戦闘ログメッセージ速度を指定する変数ID（デフォルト：なし）　（値が小さいと速くなる、戦闘速度が大きく変わるので注意)
 * @type variable
 * @default 0
 * 
 * @param initialSpeed
 * @parent logSpeedVarId
 * @text 戦闘ログ速度初期値
 * @desc 上記変数の初期値（1以上の値を入力）（ツクールデフォ：16）　　（変数IDが「なし」の場合は この初期値で固定となる）
 * @type number
 * @min 1
 * @default 16
 * 
 * @param logOpacity
 * @text 戦闘ログ不透明度
 * @desc 戦闘ログ背景の不透明度を変更（0-255、0の場合はログ消去）　　（ツクールデフォ：64）
 * @type number
 * @max 255
 * @default 64
 * 
 * @param initVolume
 * @text 音量初期設定
 * @desc 音量初期設定を行なうか（一度でもオプションを閉じると、その音量がセーブされるので反映は初回のみ）(デフォルト：ON)
 * @type boolean
 * @default true
 * 
 * @param initBGM
 * @parent initVolume
 * @text BGM音量
 * @desc 初期のBGM音量（デフォルト：60、ツクールデフォ：100）　　　（音量初期設定がON時のみ有効）
 * @type number
 * @max 100
 * @default 60
 * 
 * @param initBGS
 * @parent initVolume
 * @text BGS音量
 * @desc 初期のBGS音量（デフォルト：60、ツクールデフォ：100）　　　（音量初期設定がON時のみ有効）
 * @type number
 * @max 100
 * @default 60
 * 
 * @param initME
 * @parent initVolume
 * @text ME音量
 * @desc 初期のME音量（デフォルト：60、ツクールデフォ：100）　　　　（音量初期設定がON時のみ有効）
 * @type number
 * @max 100
 * @default 60
 * 
 * @param initSE
 * @parent initVolume
 * @text SE音量
 * @desc 初期のSE音量（デフォルト：60、ツクールデフォ：100）　　　　（音量初期設定がON時のみ有効）
 * @type number
 * @max 100
 * @default 60
 * 
 * 
 * @help
 * 
 * 【RPGツクールMZ専用プラグイン】
 * 大したことはないけど、あると少し便利な機能を集めたプラグインです
 * 
 * ＜パラメータで設定＞
 *  ・デプロイメント後もタイトルスキップ
 *  ・フェードアウトからゲーム開始
 *  ・メニューコマンド変更（ロード追加、ゲーム終了削除）
 *  ・一人旅の場合、メニューで最初のアクター選択を省略
 *  ・戦闘後ドロップアイテムのアイコン表示
 *  ・戦闘ログ速度の変数化（初期値で固定も可）
 *  ・戦闘ログ背景の不透明度の変更（ログ消去も可）
 *  ・音量初期設定
 * 
 * ＜プラグインコマンド＞
 *  ・時間指定フェードイン
 *  ・時間指定フェードアウト
 *  ・戦闘ログに文章表示
 *  ・ピクチャ全消去
 *  ・隠しアイテムA全削除
 *  ・隠しアイテムB全削除
 *  ・セルフスイッチ全初期化
 *  ・BGM音量途中変更
 *  ・BGS音量途中変更
 *  ・マップリージョン一時変更
 *  ・オプション画面の呼び出し
 *  ・ロード画面の呼び出し
 *  ・アイテム画面の呼び出し
 *  ・スキル画面の呼び出し
 *  ・装備画面の呼び出し
 *  ・ステータス画面の呼び出し
 * 
 * 利用規約はMITライセンスの通りです
 */

(() => {
    "use strict";

    const pluginName = "NLM_UsefulPluginMZ";
    const NLUPparam  = PluginManager.parameters(pluginName);
    NLUPparam.systemColor  = parseInt(NLUPparam.systemColor)  || 0;
    NLUPparam.initialSpeed = parseInt(NLUPparam.initialSpeed) || 16;
    NLUPparam.logOpacity   = parseInt(NLUPparam.logOpacity)   || 0;
    NLUPparam.fadeOutStart = NLUPparam.fadeOutStart === "true";
    NLUPparam.addLoad      = NLUPparam.addLoad      === "true";

    DataManager.NLUPtitleSkip = function() {
        this.setupNewGame();
        this._NLUPnoAutosave = true;
        SceneManager.goto(Scene_Map);
        this.NLUPfadeout();
    }

    DataManager.NLUPfadeout = function() {
        if (this.isTitleSkip() && !this.isBattleTest()
            && !this.isEventTest() && NLUPparam.fadeOutStart) {
            $gameScreen.startFadeOut(1); // タイトルスキップ時のフェードアウト開始
        }
        $gameVariables.setValue(NLUPparam.logSpeedVarId, NLUPparam.initialSpeed); // 戦闘ログ変数代入
    };

    // タイトルスキップ
    if (NLUPparam.titleSkip === "true") {
        DataManager.isTitleSkip = function() {
            return true;
        };

        Scene_GameEnd.prototype.commandToTitle = function() {
            this.fadeOutAll();
            DataManager.NLUPtitleSkip();
        };

        Scene_Gameover.prototype.gotoTitle = function() {
            DataManager.NLUPtitleSkip();
        };

        Game_Interpreter.prototype.command354 = function() {
            DataManager.NLUPtitleSkip();
            $gameSystem.disableMenu(); // メニューボタンが一瞬出るのを防ぐ
            return true;
        }; // 「タイトル画面に戻す」イベントコマンド

        const _Scene_Map_initialize = Scene_Map.prototype.initialize;
        Scene_Map.prototype.initialize = function() {
            _Scene_Map_initialize.apply(this, arguments);
            $gameSystem.enableMenu(); // メニューボタンを元に戻す
        };

        const _SM_shouldAutosave = Scene_Map.prototype.shouldAutosave;
        Scene_Map.prototype.shouldAutosave = function() {
            if (DataManager._NLUPnoAutosave) {
                DataManager._NLUPnoAutosave = false;
                return false; // タイトルマップ時はオートセーブ阻止
            } else {
                return _SM_shouldAutosave.call(this);
            }
        };
    }

    // 起動処理修正
    const _Scene_Boot_start = Scene_Boot.prototype.start;
    Scene_Boot.prototype.start = function() {
        _Scene_Boot_start.apply(this, arguments);
        this.NLUPinitVolume();
        DataManager.NLUPfadeout();
    };

    Scene_Boot.prototype.NLUPinitVolume = function() { // 初期音量設定
        const csave = StorageManager.exists("config");
        if (NLUPparam.initVolume === "true" && !csave) {
            ConfigManager["bgmVolume"] = Number(NLUPparam.initBGM) || 0;
            ConfigManager["bgsVolume"] = Number(NLUPparam.initBGS) || 0;
            ConfigManager["meVolume"]  = Number(NLUPparam.initME)  || 0;
            ConfigManager["seVolume"]  = Number(NLUPparam.initSE)  || 0;
        }
    };

    if (NLUPparam.fadeOutStart) { // タイトル後のフェードアウト開始
        const _ST_commandNewGame = Scene_Title.prototype.commandNewGame;
        Scene_Title.prototype.commandNewGame = function() {
            _ST_commandNewGame.apply(this, arguments);
            $gameScreen.startFadeOut(1);
        };
    }

    // メニューコマンド変更（ロード追加、ゲーム終了削除）
    const _WMC_addGameEndCommand = Window_MenuCommand.prototype.addGameEndCommand;
    Window_MenuCommand.prototype.addGameEndCommand = function() {
        if (NLUPparam.addLoad) {
            this.NLUPaddLoadCommand();
        }
        if (NLUPparam.deleteGameEnd !== "true") {
            _WMC_addGameEndCommand.apply(this, arguments);
        }
    };

    Window_MenuCommand.prototype.NLUPaddLoadCommand = function() {
        const enabled = this.isSaveEnabled();
        this.addCommand(NLUPparam.loadName || "ロード", "load", enabled);
    };

    if (NLUPparam.addLoad) {
        const _SM_createCommandWindow = Scene_Menu.prototype.createCommandWindow;
        Scene_Menu.prototype.createCommandWindow = function() {
            _SM_createCommandWindow.apply(this, arguments);
            this._commandWindow.setHandler("load", this.NLUPcommandLoad.bind(this));
        };

        Scene_Menu.prototype.NLUPcommandLoad = function() {
            SceneManager.push(Scene_Load);
        };
    }

    // 一人旅の場合、メニューでアクター選択を省略する
    if (NLUPparam.omitMenuActor === "true") {
        const _Scene_Menu_commandPersonal = Scene_Menu.prototype.commandPersonal;
        Scene_Menu.prototype.commandPersonal = function() {
            if ($gameParty.size() === 1) {
                this.onPersonalOk();
            } else {
                _Scene_Menu_commandPersonal.apply(this, arguments);
            }
        };
    }

    // 戦闘後ドロップアイテムのアイコン表示
    if (NLUPparam.dropIcon === "true") {
        BattleManager.displayDropItems = function() {
            const items = this._rewards.items;
            if (items.length > 0) {
                $gameMessage.newPage();
                for (const item of items) {
                    const name = "\x1bI[" + item.iconIndex + "]" + item.name;
                    $gameMessage.add(TextManager.obtainItem.format(name));
                }
            }
        };
    }

    // 戦闘ログ速度変更
    Window_BattleLog.prototype.messageSpeed = function() {
        return $gameVariables.value(NLUPparam.logSpeedVarId) || NLUPparam.initialSpeed;
    };

    // 戦闘ログ不透明度変更
    if (!NLUPparam.logOpacity) {
        Scene_Battle.prototype.logWindowRect = function() { // ログウインドウ消去
            return new Rectangle(0,0,0,0);
        };
    } else if (NLUPparam.logOpacity !== 64) {
        Window_BattleLog.prototype.backPaintOpacity = function() { // 不透明度変更
            return NLUPparam.logOpacity;
        };
    }

    // プラグインコマンド準備
    DataManager.NLUPcategory = function(category) {
        if (category !== undefined) this._NLUPcategory = category;
        return this._NLUPcategory;
    };

    DataManager.NLUPbutton = function(txt) {
        if (txt) this._NLUPbutton = txt;
        return this._NLUPbutton;
    };

    AudioManager.NLUPchangeBgm = function(volume) {
        const bgm = this._currentBgm;
        if (this.isCurrentBgm(bgm)) {
            bgm.volume = volume;
            this.updateBgmParameters(bgm);
        }
    };

    AudioManager.NLUPchangeBgs = function(volume) {
        const bgs = this._currentBgs;
        if (this.isCurrentBgs(bgs)) {
            bgs.volume = volume;
            this.updateBgsParameters(bgs);
        }
    };

    const _Game_Party_menuActor = Game_Party.prototype.menuActor;
    Game_Party.prototype.menuActor = function() {
        if (DataManager.NLUPbutton() === "false") {
            return $gameActors.actor(this._menuActorId);
        } else {
            return _Game_Party_menuActor.call(this);
        }
    };

    const _Scene_Item_start = Scene_Item.prototype.start;
    Scene_Item.prototype.start = function() {
        _Scene_Item_start.apply(this, arguments);
        const category = DataManager.NLUPcategory();
        if (category && category !== "no") {
            this._categoryWindow.selectSymbol(category);
            this._categoryWindow.deactivate();
            this._itemWindow.activate();
            this._itemWindow.selectLast();
        }
        DataManager.NLUPcategory("no");
    };

    const _Scene_Status_start = Scene_Status.prototype.start;
    Scene_Status.prototype.start = function() {
        _Scene_Status_start.apply(this, arguments);
        if (DataManager.NLUPbutton() === "false") {
            this._statusWindow.setHandler("pagedown");
            this._statusWindow.setHandler("pageup");
        }
    };

    const _SS_needsPageButtons = Scene_Status.prototype.needsPageButtons;
    Scene_Status.prototype.needsPageButtons = function() {
        return _SS_needsPageButtons.call(this) && DataManager.NLUPbutton() !== "false";
    };

    const _Scene_Status_popScene = Scene_Status.prototype.popScene;
    Scene_Status.prototype.popScene = function() {
        _Scene_Status_popScene.apply(this, arguments);
        DataManager.NLUPbutton("true");
    };

    PluginManager.NLUPnumber = function(number, varId) {
        return Number(varId === "0" ? number : $gameVariables.value(varId)) || 0;
    };

    // プラグインコマンド
    PluginManager.registerCommand(pluginName, "fadeIn", args => { // フェードイン
        const time = PluginManager.NLUPnumber(args.frame, args.fVarId) || 1;
        $gameScreen.startFadeIn(time);
    });

    PluginManager.registerCommand(pluginName, "fadeOut", args => { // フェードアウト
        const time = PluginManager.NLUPnumber(args.frame, args.fVarId) || 1;
        $gameScreen.startFadeOut(time);
    });

    PluginManager.registerCommand(pluginName, "battleLogDisp", args => { // 戦闘ログ文章表示
        const log  = BattleManager._logWindow;
        const text = args.phrase;
        if (text) log.push("addText", text);
        if (args.wait  === "true") log.push("wait");
        if (args.clear === "true") log.push("clear");
    });

    PluginManager.registerCommand(pluginName, "clearPic", args => { // ピクチャ全消去
        $gameScreen.clearPictures();
    });

    PluginManager.registerCommand(pluginName, "clearHiddenA", args => { // 隠しアイテムA全削除
        const max = $gameParty.maxItems();
        for (const item of $dataItems) {
            if (item && item.itypeId === 3) {
                $gameParty.loseItem(item, max);
            }
        }
    });

    PluginManager.registerCommand(pluginName, "clearHiddenB", args => { // 隠しアイテムB全削除
        for (const item of $dataItems) {
        const max = $gameParty.maxItems();
            if (item && item.itypeId === 4) {
                $gameParty.loseItem(item, max);
            }
        }
    });

    PluginManager.registerCommand(pluginName, "clearSelf", args => { // セルフスイッチ初期化
        $gameSelfSwitches.clear();
        $gameMap.requestRefresh();
    });

    PluginManager.registerCommand(pluginName, "volumeBgm", args => { // BGM音量変更
        const volume = PluginManager.NLUPnumber(args.volume, args.varId);
        AudioManager.NLUPchangeBgm(volume);
    });

    PluginManager.registerCommand(pluginName, "volumeBgs", args => { // BGS音量変更
        const volume = PluginManager.NLUPnumber(args.volume, args.varId);
        AudioManager.NLUPchangeBgs(volume);
    });

    PluginManager.registerCommand(pluginName, "changeRegionId", args => { // マップリージョン変更
        if (args.map) {
            const map = JSON.parse(args.map);
            const x = Number(map.x) || 0;
            const y = Number(map.y) || 0;
            const value  = PluginManager.NLUPnumber(args.region, args.varId);
            const width  = $dataMap.width;
            const height = $dataMap.height;
            $dataMap.data[(5 * height + y) * width + x] = value;
        }
    });

    PluginManager.registerCommand(pluginName, "callOption", args => { // オプション呼び出し
        SceneManager.push(Scene_Options);
    });

    PluginManager.registerCommand(pluginName, "callLoad", args => { // ロード呼び出し
        SceneManager.push(Scene_Load);
    });

    PluginManager.registerCommand(pluginName, "callItem", args => { // アイテム呼び出し
        DataManager.NLUPcategory(args.category);
        SceneManager.push(Scene_Item);
    });

    PluginManager.registerCommand(pluginName, "callSkill", args => { // スキル呼び出し
        const id = PluginManager.NLUPnumber(args.actor, args.varId);
        SceneManager.push(Scene_Skill);
        $gameParty.setMenuActor($gameActors.actor(id));
    });

    PluginManager.registerCommand(pluginName, "callEquip", args => { // 装備呼び出し
        const id = PluginManager.NLUPnumber(args.actor, args.varId);
        Window_StatusBase.prototype.loadFaceImages(); // 顔画像preload
        SceneManager.push(Scene_Equip);
        $gameParty.setMenuActor($gameActors.actor(id));
    });

    PluginManager.registerCommand(pluginName, "callStatus", args => { // ステータス呼び出し
        const id = PluginManager.NLUPnumber(args.actor, args.varId);
        SceneManager.push(Scene_Status);
        $gameParty.setMenuActor($gameActors.actor(id));
        DataManager.NLUPbutton(args.pageButton);
    });
})();
